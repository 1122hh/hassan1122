package com.example.timetable;

public class Application {
    int  id;String name ,section ,roll,application;

    public Application(int id, String name, String section, String roll, String application) {
        this.id = id;
        this.name = name;
        this.section = section;
        this.roll = roll;
        this.application = application;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getSection() {
        return section;
    }

    public String getRoll() {
        return roll;
    }

    public String getApplication() {
        return application;
    }
}

