package com.example.timetable;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class cordinater_activity extends AppCompatActivity {
    EditText nametxt,rolltxt,sectiontxt,applicationtxt,hodremarks,corRemarks;
    Button button;
  static   String curappid;
    mydatabase mydatabase11;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cordinater_activity);


        nametxt=findViewById(R.id.name);
        rolltxt=findViewById(R.id.rollnumer);
        sectiontxt=findViewById(R.id.section);
        corRemarks=findViewById(R.id.comment);
        applicationtxt=findViewById(R.id.editText);

        button=findViewById(R.id.savebtn);
        mydatabase11=new mydatabase(cordinater_activity.this);
        pudata();
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mydatabase11.cordinater_Remarksadd(curappid,nametxt.getText().toString(),rolltxt.getText().toString(),sectiontxt.getText().toString(),applicationtxt.getText().toString(),corRemarks.getText().toString());
                Toast.makeText(cordinater_activity.this,"comment is saved",Toast.LENGTH_LONG).show();
                           finish();
            }
        });

    }
    void pudata(){
        Cursor cursor= mydatabase11.showDataper(showdataactivity.myname);
        while (cursor.moveToNext())
        {
          curappid=cursor.getString(0);
            nametxt.setText(cursor.getString(1));
            rolltxt.setText(cursor.getString(2));
            sectiontxt.setText(cursor.getString(3));
            applicationtxt.setText(cursor.getString(4));
            corRemarks.setText(cursor.getString(5));

        }
    }
}
