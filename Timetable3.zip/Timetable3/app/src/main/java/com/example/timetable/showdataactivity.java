package com.example.timetable;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class showdataactivity extends AppCompatActivity {
ListView listView;
List<String> stringList;
ArrayAdapter<String> stringArrayAdapter;
static String myname;
mydatabase mydatabase2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showdataactivity);
        listView=findViewById(R.id.listdata);
        mydatabase2=new mydatabase(showdataactivity.this);
        stringList=new ArrayList<String>();
        put();
        stringArrayAdapter=new ArrayAdapter<String>(showdataactivity.this,android.R.layout.simple_list_item_1,stringList);
        listView.setAdapter(stringArrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                myname=stringList.get(position);
                if(MainActivity.t.equals("cordinater")) {
                    Intent intent = new Intent(showdataactivity.this, cordinater_activity.class);
                    startActivity(intent);
                }
                else if(MainActivity.t.equals("hod")){
                    Intent intent = new Intent(showdataactivity.this, Hod_Activity.class);
                    startActivity(intent);
                }
            }
        });

    }

    void put(){
        Cursor cursor= mydatabase2.Showdata();
        while (cursor.moveToNext())
        {
            stringList.add(cursor.getString(1));

        }
    }


}
