package com.example.timetable;

import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ReterofitClient {
   static String url="https://180.106.246.161:49959/api/";

    public static void CheckData( )
    {
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl(url)
                .addConverterFactory(GsonConverterFactory.create() )
                .build();
        MyApiCaller api=retrofit.create(MyApiCaller.class);

        Call<List<login>> listCall=api.getAllUser();
        // to execute in other thread....
        listCall.enqueue(new Callback<List<login>>() {
            @Override
            public void onResponse(Call<List<login>> call, Response<List<login>> response) {
                if((!response.isSuccessful()))
                {

                }


            }

            @Override
            public void onFailure(Call<List<login>> call, Throwable t) {

            }
        });
    }

public static List<login> logins=new ArrayList<>();
    public static void LoadData( )
    {
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl(url)
                .addConverterFactory(GsonConverterFactory.create() )
                .build();
        MyApiCaller api=retrofit.create(MyApiCaller.class);

        Call<List<login>> listCall=api.getAllUser();
        // to execute in other thread....
        listCall.enqueue(new Callback<List<login>>() {
            @Override
            public void onResponse(Call<List<login>> call, Response<List<login>> response) {
                if((!response.isSuccessful()))
                {
                    List<login> logins1=new ArrayList<>();
                    logins1=response.body();
                logins.addAll(logins1);
                }


            }

            @Override
            public void onFailure(Call<List<login>> call, Throwable t) {

            }
        });
    }

}

