package com.example.timetable;

import java.util.List;

import okhttp3.Response;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface MyApiCaller
{
    @GET("/login")
    Call<List<login>> getAllUser();
    @POST("/login")
    Call<List<login>> Create();
    @GET("/users")
    Call<List<Application>> getAllUserApplication();
}
