package com.example.timetable;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class student_Activity extends AppCompatActivity {
EditText nametxt,rolltxt,sectiontxt,applicationtxt;
Button button;
mydatabase mydatabase11;
String myid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_);
        Intent i=getIntent();
        myid=i.getStringExtra("id");
        nametxt=findViewById(R.id.name);
        rolltxt=findViewById(R.id.rollnumer);
        sectiontxt=findViewById(R.id.section);
        applicationtxt=findViewById(R.id.editText);
        button=findViewById(R.id.submitbtn);
        mydatabase11=new mydatabase(student_Activity.this);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mydatabase11.Insert(MainActivity.id,nametxt.getText().toString(),rolltxt.getText().toString(),sectiontxt.getText().toString(),applicationtxt.getText().toString());

                Toast.makeText(student_Activity.this,"application is saved",Toast.LENGTH_LONG).show();
                finish();
            }

        });













    }
}
