package com.example.timetable;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText boxname,boxpasword;
    Button button;
    static   String n,p,t,id;
    mydatabase mydatabase1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    boxname=findViewById(R.id.username);
    boxpasword=findViewById(R.id.password);
    button=findViewById(R.id.buttonlogin);
    mydatabase1=new mydatabase(MainActivity.this);
    button.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            n=boxname.getText().toString();
            p=boxpasword.getText().toString();

            if(CheckLoginUser())
            {
                if(t.equals("hod"))
                {
                    Intent intent=new Intent(MainActivity.this,showdataactivity.class);
                    intent.putExtra("id",id);
                    startActivity(intent);
                }
                else if(t.equals("student")){
                    Intent intent=new Intent(MainActivity.this,student_Activity.class);
                    startActivity(intent);
                }
                else if (t.equals("cordinater")){
                    Intent intent=new Intent(MainActivity.this,showdataactivity.class);
                    startActivity(intent);
                }

            }
            else {
//finish();
            }
        }
    });

    }
   boolean CheckLoginUser(){
        boolean b=false;

       Cursor cursor= mydatabase1.getloginData(n);
       while (cursor.moveToNext())
       {
           if(cursor.getString(1).equals(n)&&cursor.getString(2).equals(p))
           {  b=true;
           t=cursor.getString(3);
           id=cursor.getString(0);
           Log.i("id",id);
               break;
           }
       }

        return b;
    }
}
