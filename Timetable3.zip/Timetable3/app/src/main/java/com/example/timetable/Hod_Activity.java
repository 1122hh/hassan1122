package com.example.timetable;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Hod_Activity extends AppCompatActivity {
    EditText nametxt,rolltxt,sectiontxt,applicationtxt,hodremarks,corRemarks;
    Button button;
    mydatabase mydatabase11;
    static  String curappid_hod;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hod_);


        nametxt=findViewById(R.id.name);
        rolltxt=findViewById(R.id.rollnumer);
        sectiontxt=findViewById(R.id.section);
        corRemarks=findViewById(R.id.corRemarks);
        hodremarks=findViewById(R.id.remarks);
        applicationtxt=findViewById(R.id.editText);
        button=findViewById(R.id.savebtn);
        mydatabase11=new mydatabase(Hod_Activity.this);
        put();
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
mydatabase11.Hod_Remarksadd(curappid_hod,nametxt.getText().toString(),rolltxt.getText().toString(),sectiontxt.getText().toString(),applicationtxt.getText().toString(),corRemarks.getText().toString(),hodremarks.getText().toString());
                Toast.makeText(Hod_Activity.this,"application is saved",Toast.LENGTH_LONG).show();

                finish();

            }
        });

    }
    void put(){
        Cursor cursor= mydatabase11.showDataper(showdataactivity.myname);
        while (cursor.moveToNext())
        {
            curappid_hod=cursor.getString(0);
            nametxt.setText(cursor.getString(1));
            rolltxt.setText(cursor.getString(2));
            sectiontxt.setText(cursor.getString(3));
            applicationtxt.setText(cursor.getString(4));
            corRemarks.setText(cursor.getString(5));
            hodremarks.setText(cursor.getString(6));
        }
    }
}
