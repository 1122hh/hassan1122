package com.example.timetable;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;
public class mydatabase extends SQLiteOpenHelper {


    public mydatabase(@Nullable Context context) {
        super(context, "student", null, 3);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("create table login (userid integer primary key AUTOINCREMENT , username text unique,pasword text,usertype text)");
        db.execSQL("insert into login(username,pasword,usertype) values('hassan','hassan','hod')");
        db.execSQL("insert into login(username,pasword,usertype) values('ali','hassan','cordinater')");
        db.execSQL("insert into login(username,pasword,usertype) values('abbas','hassan','student')");
        db.execSQL("insert into login(username,pasword,usertype) values('adi','hassan','student')");
        db.execSQL("insert into login(username,pasword,usertype) values('subhan','hassan','student')");
        db.execSQL("insert into login(username,pasword,usertype) values('shan','hassan','student')");
        db.execSQL("create table users (userid integer  , username  text unique,rollnumber text,sectionn text,applicationn text,comment text,status text)");

    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists login");
        db.execSQL("drop table if exists users");
        onCreate(db);
    }
   public Cursor getloginData(String unsername){
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor cursor=db.rawQuery("select *from login where username ='"+unsername+"'",null);
        return cursor;
    }
 public    Cursor Showdata(){
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor cursor=db.rawQuery("select *from users",null);
        return cursor;
    }
   public Cursor showDataper(String unsername){
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor cursor=db.rawQuery("select *from users where username ='"+unsername+"'",null);
        return cursor;
    }
    void Insert(String id,String username,String rollnumber,String section,String application){
        SQLiteDatabase db=getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("userid", Integer.parseInt(id));
        contentValues.put("username",username);
        contentValues.put("rollnumber",rollnumber);
        contentValues.put("sectionn",section);
        contentValues.put("applicationn",application);
        db.insert("users",null,contentValues);
    }
  public void  Hod_Remarksadd(String id,String username,String rollnumber,String section,String application,String comment,String remarks){

       SQLiteDatabase db=getWritableDatabase();
       ContentValues contentValues=new ContentValues();
       contentValues.put("userid", Integer.parseInt(id));
       contentValues.put("username",username);
       contentValues.put("rollnumber",rollnumber);
       contentValues.put("sectionn",section);
       contentValues.put("applicationn",application);
       contentValues.put("comment",comment);
       contentValues.put("status",remarks);
       db.update("users",contentValues,"username = ?",new String[]{username});
    }
 public    void  cordinater_Remarksadd(String id,String username,String rollnumber,String section,String application,String comment){

        SQLiteDatabase db=getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("userid", Integer.parseInt(id));
        contentValues.put("username",username);
        contentValues.put("rollnumber",rollnumber);
        contentValues.put("sectionn",section);
        contentValues.put("applicationn",application);
        contentValues.put("comment",comment);
        db.update("users",contentValues,"username = ?",new String[]{username});
    }
}
